package com.chloe.doesntknowhowtocode;

import java.awt.*;

public class Main {

    public static void main(String args[]) {

        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        Engine e = new Engine((int) size.getHeight()-200, (int) size.getHeight()-200);
        e.setUp();
        e.run();

    }

}
