package com.chloe.doesntknowhowtocode;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JFrame;

public class Engine implements MouseListener, MouseMotionListener{

    private Board b;
    private int w;
    private int h;
    private boolean running;
    private final int UPDATES_PER_SEC = 5;
    private Graphics2D gr;
    private GameStates state;

    public Engine (int w, int h) {
        this.w = w;
        this.h = h;
        running = false;
        b = new Board(w, h);
    }

    public void setUp() {

        b.setUp(this, this, this);
        gr = b.getGraphics2D();
        b.makeTiles(15);
        state = GameStates.MENU;

    }

    public void setState(GameStates sta) {
        state = sta;
    }

    public void run() {
        setRunning(true);

        long startTime = 0L;
        long sleepDuration = 0L;

        while (isRunning()) {
            startTime = System.currentTimeMillis();

            update();
            b.render(gr, state);

            b.getCanvas().getBufferStrategy().show();

            sleepDuration = 10 - (System.currentTimeMillis() - startTime);

            if (sleepDuration > 0) {
                try {
                    Thread.sleep(sleepDuration);
                } catch(Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void update() {

    }

    public boolean isRunning() {
        return running;
    }

    public void setRunning(boolean running) {
        this.running = running;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        b.clickedMouse(e);
    }

    @Override
    public void mousePressed(MouseEvent e) {
        b.pressedMouse(e);
    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        b.draggedMouse(e);
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
