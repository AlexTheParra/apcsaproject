package com.chloe.doesntknowhowtocode;

public enum GameStates {
    MENU, IN_GAME, WON, INSTRUCTIONS
}
