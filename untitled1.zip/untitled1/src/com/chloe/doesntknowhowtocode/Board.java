package com.chloe.doesntknowhowtocode;

import java.awt.*;

import javax.swing.*;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Board {

    private int w;
    private int h;
    private Canvas c;
    private Graphics2D g;
    private ArrayList<ArrayList<Integer>> tiles;
    private int nTiles;
    private boolean inDrag;
    private int startX;
    private int startY;
    private int startPos;
    private Font f;
    private GameStates pState;
    private ArrayList<String> rowsCheck;
    private ArrayList<String> colsCheck;
    private Engine e;

    public Board(int w, int h) {

        this.w = w;
        this.h = h;
        tiles = new ArrayList<>();
        nTiles = 0;

    }

    public void setUp(MouseListener listener, MouseMotionListener motion, Engine engine) {

        JFrame frame = new JFrame("Pixel Cross");
        frame.setBackground(Color.BLACK);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);

        e = engine;

        rowsCheck = new ArrayList<>();

        colsCheck = new ArrayList<>();

        try {
            f = Font.createFont(Font.TRUETYPE_FONT,
                    new FileInputStream("/Users/alexanderparra23/IdeaProjects/untitled1/src/com/chloe/doesntknowhowtocode/stingray.ttf"));
            f = f.deriveFont(Font.PLAIN);
        } catch (FontFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        inDrag = false;
        startX = 0;
        startY = 0;
        startPos = 0;

        c = new Canvas();
        c.setBackground(Color.WHITE);
        System.out.println(w + " " + h);
        c.setSize(new Dimension(w, h));
        pState = GameStates.MENU;

        c.addMouseListener(listener);
        c.addMouseMotionListener(motion);

        frame.add(c);
        frame.pack();
        frame.setVisible(true);

        c.createBufferStrategy(2);
        g = (Graphics2D) c.getBufferStrategy().getDrawGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    }

    public Graphics2D getGraphics2D() {
        return g;
    }

    public Canvas getCanvas() {
        return c;
    }

    public void makeTiles(int numTiles) {
        tiles.clear();
        nTiles = numTiles;
        System.out.println(nTiles);
        for (int i = 0; i < nTiles; i++) {
            tiles.add(new ArrayList<>());
            for (int x = 0; x < nTiles; x++) {
                tiles.get(i).add(0);
            }

        }
        File f = new File("/Users/alexanderparra23/IdeaProjects/untitled1/src/com/chloe/doesntknowhowtocode/Puzzle15by15_" + 2 + ".txt");

        try {
            Scanner in = new Scanner(f);

            for (int i = 0; i < nTiles; i++) {
                rowsCheck.add(in.nextLine());
            }
            in.nextLine();
            for (int i = 0; i < nTiles; i++) {
                colsCheck.add(in.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void clickedMouse(MouseEvent e) {
        if (pState ==  GameStates.MENU) {
            this.e.setState(GameStates.IN_GAME);
        }
        if (pState == GameStates.IN_GAME) {

            int row = (e.getY() - (h / (nTiles + 1))) / (h / (nTiles + 1));
            int col = (e.getX() - (w / (nTiles + 1))) / (w / (nTiles + 1));

            tiles.get(row).set(col, (tiles.get(row).get(col) == 1) ? 0 : 1);

            System.out.println(e.getX() + ", " + e.getY());

        }
    }

    public void pressedMouse(MouseEvent e) {

        if (pState == GameStates.IN_GAME) {
            Point p = e.getPoint();
            startX = p.x;
            startY = p.y;
            inDrag = true;
            int row = (e.getY() - (h / (nTiles + 1))) / (h / (nTiles + 1));
            int col = (e.getX() - (w / (nTiles + 1))) / (w / (nTiles + 1));

            if (tiles.get(row).get(col) == 0) {
                startPos = 1;
            } else {
                startPos = 0;
            }
            System.out.println(startPos);
        }


    }

    public void render(Graphics2D g, GameStates state) {
        g.clearRect(0,0, w, h);
        g.setColor(Color.BLACK);

        pState = state;

        if (state == GameStates.MENU) {
            Font bFont = new Font( "Comic Sans MS", Font.PLAIN, 75);
            g.setFont(bFont);
            g.drawString("Pixel Cross", w/2 - (g.getFontMetrics(bFont).stringWidth("Pixel Cross")/2), h/2);

            Font sFont = new Font("Comis Sans MS", Font.PLAIN, 20);
            g.setFont(sFont);
            g.drawString("Start", w/2 - (g.getFontMetrics(sFont).stringWidth("Start")/2) , h/2 + 50);

            g.drawOval(287, 500, 300, 280);
            g.setColor(Color.gray);
            g.fillOval(287, 500, 300, 280);
        }


        if (state == GameStates.IN_GAME) {
            int newTiles = nTiles + 1;

            ArrayList<Boolean> rowsFilled = Algorithms.getRowsFilled(tiles, rowsCheck);
            ArrayList<Boolean> colsFilled = Algorithms.getColsFilled(tiles, colsCheck);

            //System.out.println(colsFilled);

            for (int i = 1; i <= nTiles; i++) {
                for (int x = 1; x <= nTiles; x++) {
                    if (tiles.get(i - 1).get(x - 1) == 1) {
                        g.fillRect(x * (w / newTiles), i * (h / newTiles), w / newTiles, h / newTiles);
                    } else {
                        g.drawRect(x * (w / newTiles), i * (h / newTiles), w / newTiles, h / newTiles);
                    }
                }
            }
            FontMetrics fontMetrics = g.getFontMetrics(g.getFont());
            for (int i = 1; i < rowsFilled.size()+1; i++) {
                g.setColor(Color.GREEN);
                if (rowsFilled.get(i-1)) {
                    g.fillRect(0, i * (h / newTiles), w / newTiles, h / newTiles);
                }
                if (colsFilled.get(i-1)) {
                    g.fillRect(i * (w/newTiles), 0, w/newTiles, h/newTiles);
                }
                g.setColor(Color.BLACK);
                g.drawString(rowsCheck.get(i-1), (h/newTiles/2) - (fontMetrics.stringWidth(rowsCheck.get(i-1))/2), i * (h/newTiles) + (h/newTiles/2));
                g.drawString(colsCheck.get(i-1), i * (h/newTiles) + (h/newTiles/2) - (fontMetrics.stringWidth(colsCheck.get(i-1))/2), (h/newTiles/2));

            }
        }
    }

    public void draggedMouse(MouseEvent e) {
        if (pState == GameStates.IN_GAME) {
            int row = (e.getY() - (h / (nTiles + 1))) / (h / (nTiles + 1));
            int col = (e.getX() - (w / (nTiles + 1))) / (w / (nTiles + 1));

            tiles.get(row).set(col, startPos);
        }
    }
}
