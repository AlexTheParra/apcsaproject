package com.chloe.doesntknowhowtocode;

import java.util.ArrayList;
import java.util.Arrays;

public class Algorithms {

    public static ArrayList<Boolean> getRowsFilled(ArrayList<ArrayList<Integer>> tiles, ArrayList<String> shouldBe) {
        ArrayList<Boolean> array = new ArrayList<>();

        for (int i = 0; i < tiles.size(); i++) {
            ArrayList<Integer> row = tiles.get(i);

            String[] check = shouldBe.get(i).split(" "); //splits string
            ArrayList<Integer> checkInts = new ArrayList<>(); //makes checkInts
            for (int x = 0; x < check.length; x++) { //loops
                checkInts.add(Integer.parseInt(check[x]));
            }

            ArrayList<Integer> groups = new ArrayList<>();

            int currGroup = 0;
            boolean black = false;

            for (int x = 0; x < row.size(); x++) {
                if (row.get(x) == 1) {
                    black = true;
                    currGroup++;
                } else if (row.get(x) == 0 && black) {
                    groups.add(currGroup);
                    currGroup = 0;
                    black = false;
                } else {
                    currGroup = 0;
                    black = false;
                }
                if (currGroup > 0 && x == row.size()-1) {
                    groups.add(currGroup);
                }
            }

            array.add(groups.equals(checkInts));
        }

        return array;
    }

    public static ArrayList<Boolean> getColsFilled(ArrayList<ArrayList<Integer>> tiles, ArrayList<String> shouldBe) {
        ArrayList<Boolean> array = new ArrayList<>();

        ArrayList<ArrayList<Integer>> rowCol = new ArrayList<>();

        for (int i = 0; i < tiles.size(); i++){
            rowCol.add(new ArrayList<>());
        }

        for (int i = 0; i < tiles.size(); i++) {
            for (int x = 0; x < tiles.get(0).size(); x++) {
                rowCol.get(x).add(tiles.get(i).get(x));
            }
        }

        for (int i = 0; i < tiles.size(); i++) {
            ArrayList<Integer> row = rowCol.get(i);

            String[] check = shouldBe.get(i).split(" "); //splits string
            ArrayList<Integer> checkInts = new ArrayList<>(); //makes checkInts
            for (int x = 0; x < check.length; x++) { //loops
                checkInts.add(Integer.parseInt(check[x]));
            }

            ArrayList<Integer> groups = new ArrayList<>();

            int currGroup = 0;
            boolean black = false;

            for (int x = 0; x < row.size(); x++) {
                if (row.get(x) == 1) {
                    black = true;
                    currGroup++;
                } else if (row.get(x) == 0 && black) {
                    groups.add(currGroup);
                    currGroup = 0;
                    black = false;
                } else {
                    currGroup = 0;
                    black = false;
                }
                if (currGroup > 0 && x == row.size()-1) {
                    groups.add(currGroup);
                }
            }

            array.add(groups.equals(checkInts));
            //System.out.println(groups + " " + checkInts);
        }

        return array;
    }

}
